Asad Mehdi
Lab 1: HTML5, CSS3, JS, BOOTSTRAP, TWITTER

This lab contains 5 files:
- lab1.html contains the markup for the tweets
- lab1.css contains the styling for the markup
- lab1.js contains the JavaScript code that dynamically puts each tweet/username onto the page
- TwitterTweets17.json is the JSON file that provides the data
- README.txt is this current file

For this lab I decided to create 2 different feeds: one feed for each tweet with a profile picture associated with it, and another feed for the usernames. All this was done with JavaScript and jQuery. Please see the commented lab1.js file for more information on what was done.

Have a nice day! :)